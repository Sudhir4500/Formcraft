// app/(dashboard)/dashboard/page.tsx
import type { Metadata } from 'next'
import { Form } from '@/types/forms'

export const metadata: Metadata = {
  title: 'Dashboard — FormCraft',
  description: 'Manage your forms',
}

export default async function DashboardPage() {
  let forms: Form[] = []
  let error = null

  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/api/forms`, {
      cache: 'no-store',
      credentials: 'include',
    })
    
    const data = await res.json()
    
    if (!res.ok) {
      // If status is 401, the user might need to login
      if (res.status === 401) {
        error = 'Please log in to view your forms'
      } else {
        error = data.message || 'Failed to load forms'
      }
    } else if (data.success) {
      forms = data.data || []
    } else {
      error = data.message || 'Failed to load forms'
    }
  } catch (err) {
    error = 'Unable to connect to server. Please try again later.'
    console.error('Dashboard fetch error:', err)
  }

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <h1 className="text-2xl font-semibold mb-4">My Forms</h1>

      {error ? (
        <div className="text-red-500 bg-red-50 p-4 rounded-lg border border-red-200">
          {error}
        </div>
      ) : forms.length === 0 ? (
        <div className="text-gray-500">No forms yet. Create one!</div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {forms.map((form) => (
            <div
              key={form.id}
              className="rounded-lg border border-gray-200 p-4 shadow-sm bg-white"
            >
              <h2 className="text-lg font-medium">{form.title}</h2>
              <p className="text-sm text-gray-500">Slug: {form.slug}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}