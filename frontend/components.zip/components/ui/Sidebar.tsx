'use client'
import { useAuthStore } from '@/store/authStore'
import { Modal } from './Modal'
import React from 'react'
import { LogoutButton } from '../auth/LogoutButton'

interface SidebarProps {
  children?: React.ReactNode
}

export function Sidebar({ children }: SidebarProps) {
  const [isModalOpen, setIsModalOpen] = React.useState(false)
  const { user } = useAuthStore()

  const openModal = () => {
    setIsModalOpen(true)
  }

  return (
    <div className="drawer lg:drawer-open">
      <input id="my-drawer-4" type="checkbox" className="drawer-toggle" />
      <div className="drawer-content">
        {/* Navbar */}
        <nav className="navbar w-full bg-base-300">
          <label
            htmlFor="my-drawer-4"
            aria-label="open sidebar"
            className="btn btn-square btn-ghost"
          >
            {/* Sidebar toggle icon */}
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              strokeLinejoin="round"
              strokeLinecap="round"
              strokeWidth="2"
              fill="none"
              stroke="currentColor"
              className="my-1.5 inline-block size-4"
            >
              <path d="M4 4m0 2a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2z"></path>
              <path d="M9 4v16"></path>
              <path d="M14 10l2 2l-2 2"></path>
            </svg>
          </label>
          <div className="px-4">FormCraft</div>
        </nav>
        {/* Page content here */}
        <div className="p-4">{children}</div>
      </div>

      <div className="drawer-side is-drawer-close:overflow-visible">
        <label
          htmlFor="my-drawer-4"
          aria-label="close sidebar"
          className="drawer-overlay"
        ></label>
        <div className="flex min-h-full flex-col items-start bg-base-200 is-drawer-close:w-14 is-drawer-open:w-64">
          {/* Sidebar content here */}
          <ul className="menu w-full grow">
            {/* List item */}
            <li>
              <button
                className="is-drawer-close:tooltip is-drawer-close:tooltip-right"
                data-tip="Homepage"
              >
                {/* Home icon */}
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  strokeLinejoin="round"
                  strokeLinecap="round"
                  strokeWidth="2"
                  fill="none"
                  stroke="currentColor"
                  className="my-1.5 inline-block size-4"
                >
                  <path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"></path>
                  <path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                </svg>
                <span className="is-drawer-close:hidden">Homepage</span>
              </button>
            </li>

            {/* List item */}
            <li>
              <button
                className="is-drawer-close:tooltip is-drawer-close:tooltip-right"
                data-tip="Settings"
              >
                {/* Settings icon */}
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  strokeLinejoin="round"
                  strokeLinecap="round"
                  strokeWidth="2"
                  fill="none"
                  stroke="currentColor"
                  className="my-1.5 inline-block size-4"
                >
                  <path d="M20 7h-9"></path>
                  <path d="M14 17H5"></path>
                  <circle cx="17" cy="17" r="3"></circle>
                  <circle cx="7" cy="7" r="3"></circle>
                </svg>
                <span className="is-drawer-close:hidden">Settings</span>
              </button>
            </li>
          </ul>

          {/* Sidebar footer */}
          <div className="w-full border-t border-base-300 p-4">
            <button
              className="is-drawer-close:tooltip is-drawer-close:tooltip-right"
              data-tip={`${user?.name || 'User'}`}
              onClick={openModal}
            >
              {/* user face icon */}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                strokeLinejoin="round"
                strokeLinecap="round"
                strokeWidth="2"
                fill="none"
                stroke="currentColor"
                className="my-1.5 inline-block size-4"
              >
                <path d="M12 7a4 4 0 1 0 0 -8a4 4 0 0 0 0 8z"></path>
                <path d="M6.168 21a8.959 8.959 0 0 1 .008 -16h.016a8.959 8.959 0 0 1 .008 16z"></path>
              </svg>
              <span className="is-drawer-close:hidden">{user?.name}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Modal content */}
    {isModalOpen && (
  <Modal 
    title="Account Settings" 
    open={isModalOpen} 
    onClose={() => setIsModalOpen(false)}
  >
    <div className="space-y-6">
      {/* User Info Section */}
      <div className="space-y-4">
        <div>
          <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
            Full Name
          </label>
          <p className="text-gray-900 dark:text-white text-base font-medium mt-1">
            {user?.name || "N/A"}
          </p>
        </div>
        
        <div>
          <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
            Email Address
          </label>
          <p className="text-gray-900 dark:text-white text-base font-medium mt-1">
            {user?.email || "N/A"}
          </p>
        </div>
      </div>

      {/* Action Footer */}
      <div className="pt-6 border-t border-gray-100 dark:border-gray-800 flex justify-end">
        <LogoutButton />
      </div>
    </div>
  </Modal>
)}
    </div>
  )
}