import React from 'react'

interface ModalProps {
  children?: React.ReactNode
  title?: string
  open: boolean
  onClose: () => void
}

export function Modal({ title, children, open, onClose }: ModalProps) {
  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm transition-opacity">
      {/* Overlay click to close */}
      <div className="absolute inset-0" onClick={onClose} />
      
      <div className="relative w-full max-w-md dark:bg-gray-900 border border-gray-200 dark:border rounded-2xl shadow-2xl p-6 animate-in fade-in zoom-in duration-200">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-foreground/80 dark:text-foreground">
            {title}
          </h3>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-foreground/60 hover:text-foreground/80 dark:hover:text-foreground/40 hover:bg-gray-100 dark:hover:bg-background/80 transition"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" viewBox="0 0 20 20" fill="currentColor">
              <path d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" />
            </svg>
          </button>
        </div>

        {/* Body */}
        <div className="text-foreground/60 dark:text-foreground/40 mb-6">
          {children}
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-3 pt-4 border-t border-gray-100 dark:border-gray-800">
          <button
            onClick={onClose}
            className="px-5 py-2 text-sm font-medium text-foreground/60 dark:text-foreground/40 bg-background/80 dark:bg-background/80 hover:bg-background/100 dark:hover:bg-background/100 rounded-xl transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  )
}