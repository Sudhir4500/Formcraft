// @/lib/api/forms.ts
// Client-side API helpers — hit the Next.js BFF routes (not Django directly)
import { apiGet, apiPost, apiPatch, apiDelete } from '@/services/apiClient'
import type { Form, Question } from '@/types/forms'

export function getForms() {
  return apiGet<Form[]>('/api/forms/')
}

export function getForm(slug: string) {
  return apiGet<Form>(`/api/forms/${slug}/`)
}

export function createForm(title: string) {
  return apiPost<Form>('/api/forms/', { title })
}

export function updateForm(slug: string, body: Partial<Pick<Form, 'title' | 'description' | 'success_message' | 'is_published'>>) {
  return apiPatch<Form>(`/api/forms/${slug}/`, body)
}

export function deleteForm(slug: string) {
  return apiDelete<void>(`/api/forms/${slug}/`)
}

export function addQuestion(slug: string, data: Record<string, unknown>) {
  return apiPost<Question>(`/api/forms/${slug}/questions/`, data)
}

export function updateQuestion(slug: string, questionId: number, data: Partial<Question>) {
  return apiPatch<Question>(`/api/forms/${slug}/questions/${questionId}/`, data)
}

export function deleteQuestion(slug: string, questionId: number) {
  return apiDelete<void>(`/api/forms/${slug}/questions/${questionId}/`)
}

export function reorderQuestions(slug: string, orderedIds: number[]) {
  return apiPost<void>(`/api/forms/${slug}/questions/reorder/`, { ordered_ids: orderedIds })
}
